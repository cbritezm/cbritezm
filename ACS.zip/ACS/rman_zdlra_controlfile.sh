export NLS_DATE_FORMAT='DD/MM/YYYY HH24:MI:SS'
export ORACLE_SID=$1
export ORACLE_BASE=$2
export ORACLE_HOME=$3
export TNS_ADMIN=
export ZDLRA_CONN=$4

$ORACLE_HOME/bin/rman target / catalog /@$ZDLRA_CONN cmdfile=/home/oracle/ACS/rman_zdlra_controlfile.cmd log=/home/oracle/ACS/logs/backup_zdlra_${ORACLE_SID}.`date +%Y%m%d%H%M%S`_controlfile.log

