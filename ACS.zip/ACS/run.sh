export NLS_DATE_FORMAT='DD/MM/YYYY HH24:MI:SS'
/home/oracle/ACS/rman_zdlra_setprod01_level0.sh
